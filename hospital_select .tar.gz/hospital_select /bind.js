var mysql = require('mysql');  
var TEST_DATABASE = 'frt';  
var TEST_TABLE = 't_recipe';  
//创建连接  
var options = {  
   host     : '127.0.0.1',      
   user     : 'root',             
   password : 'pude2015',      
   port: '3306',                  
   database: TEST_DATABASE ,
};  
var vma = new Vue({
    el: '#medical',
    data: {
       param:'',
       recipe_results : '',
       message:'',
       reciper_results : [],
},
  methods: {
    search_table:function(){
       vma.reciper_results = [];
       document.getElementById("prescription").style.display = "none";
       var a= this.message.trim();
        //  console.log(a);
       sql="select * from "+TEST_TABLE+" where patient_name like '%"+a+"%' or dingbing like '%"+a+"%'  order by patient_no ,update_date desc";
       if(a !=''){
       show_table(sql);
         }
      },
    details:function(e,row){
      var recipe_no = row.recipe_no;
      var patient_name =row.name;
      var date_time =row.date_time;
      var bingzheng =row.dingxing;

      obj = e.target;
      change_color(obj);
      obj.style.display = "none";
      obj.parentNode.childNodes[2].style.display = 'block';
      var tr = obj.parentNode.parentNode;
      var client = mysql.createConnection(options);
      document.getElementById("prescription").style.display = "inline-block";
      var sql ="select medicine,count,unit from t_recipe_item where recipe_id='"+recipe_no+"'";
      client.query(  
      sql, function(err, results, fields) {  
       client.end();
       if (err) {
            document.write(sql);
            document.write("---------error---------"); 
            throw err;  
            document.write("---------error---------"); 
        }
       if(results)
        { 
            var objB= [];
            var objC = [];
     //   console.log(results);
           for(var i = 0; i < results.length; i++)
           {  
                 var row = {};
                 row.medicine = results[i].medicine;
                 row.count = results[i].count;
                 row.unit= results[i].unit;
                 objB.push(row);
             } 
                 var objD = {};
                 objD.recipe_no = recipe_no;
                 objD.name=patient_name;
                 objD.date_time=date_time;
                 objD.dingxing =bingzheng ;
                 objD.recipe_detail = objB;
                 
            //     console.log(objD);
                 vma.reciper_results.push(objD);
            //      console.log( vma.reciper_results); 
             }
      });
},
        removetodo:function(e,row){
            var obj = e.target;
            var recip_no = row.recipe_no;
            obj.parentNode.childNodes[0].style.display = 'block';
            obj.style.display = 'none';
             reciper_array = vma.reciper_results;
             row.bgcolor = "white";
        //  console.log(reciper_array.length);
             for(i=0;i<reciper_array.length;i++){
               if(recip_no == reciper_array[i].recipe_no){
                  reciper_array.splice(i,1);
                  obj.parentNode.parentNode.className="hidden";
                }
            } 
        },
	search:function(){
	   var client = mysql.createConnection(options);
	   var sql1= sql2=sql3=sql4=' ';
	   var name=document.getElementById('name').value.trim();
	   var disease=document.getElementById('dingbing').value.trim();
	   var doctor=document.getElementById('doctor').value.trim();
	   var time1=document.getElementById('time1').value.trim();
          var time2=document.getElementById('time2').value.trim();
          var sex=document.getElementById('sex').value.trim();
	      if(name!='') {
		sql1="patient_name like '%"+name+"%'";
	      }else{sql1="patient_name like '%%'";}
	      if(disease!=''){
		sql2=" and dingbing like '%"+disease+"%'";  
	      }else{console.log(disease);}
	      if(doctor!=""){
		 sql3="and doctor_name like '%"+doctor+"%'";  
	      }
	      if(time1!="" && time2!=''){
		 sql4="and update_date  between '"+time1+"' and '"+time2+"'";
	      }
	      var sql="select * from "+ TEST_TABLE +" where "+sql1+sql2+sql3+sql4+" and sex ='"+sex+"' order by patient_no ,update_date desc";	
              show_table(sql);
        },
    }
});
function show_table(sql) { 
var client = mysql.createConnection(options);
  client.query(sql,function(err, results, fields) {  
  client.end();
    if (err) {
      throw err;  
    }   
    if(results)
       {  
//     console.log(sql); 
        document.getElementById('count').innerHTML = results.length;
        var objA = [];
        for(var i = 0; i < results.length; i++)
        {  
           var newDate = new Date();
           newDate.setTime(results[i].update_date);
           var row = {};
           row.name = results[i].patient_name;
           row.sex = results[i].sex;
           row.age = results[i].age;
           row.doctor = results[i].doctor_name;
           row.dingxing = results[i].dingbing+","+ results[i].dingzheng+","+results[i].dingxing ;
           row.comment  = results[i].comment;
           row.date_time = newDate.toLocaleDateString(results[i].update_date) ;
           row.recipe_no =results[i].recipe_no;
           objA.push(row);
              }
            vma.recipe_results =objA;
           }; 
        });
      }
//改变颜色
var CURRENT_ACTIVE = null;
function change_color(obj){
//  console.log( CURRENT_ACTIVE);
  obj.style.display = "none"; 
    if( null == CURRENT_ACTIVE ){   
        CURRENT_ACTIVE = obj;
    }else if("hidden" ==CURRENT_ACTIVE.parentNode.parentNode.className){
      CURRENT_ACTIVE = obj;
    }
    else { 
        CURRENT_ACTIVE.parentNode.parentNode.className="visited";
        CURRENT_ACTIVE = obj;    
    }
     obj.parentNode.parentNode.className="active";   
     obj.parentNode.childNodes[2].style.display = 'block';
     var tr = obj.parentNode.parentNode;
}