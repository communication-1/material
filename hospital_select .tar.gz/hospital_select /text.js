var TEST_DATABASE = 't_recipe';  
var TEST_TABLE = 't_recipe';  
//连接数据库
var mysql  = require('mysql'); 
var connection = mysql.createConnection({    
  host          : '127.0.0.1',      
  user          : 'root',             
  password  : 'pude2015',      
  port          : '3306',                  
  database   : TEST_DATABASE ,

});
connection.connect();
var fs = require("fs");
var text = fs.readFileSync("./数据.txt", "utf8");
var i=0;
// 将文件按行拆成数组
text.split(/\r?\n/).forEach(function (line) {
	// ...
	i++;
	var  userAddSql_Params =line.split(/\t/);
	var  userAddSql = 'INSERT INTO  t_recipe(patient_name,age,sex,patient_no,doctor_name,dingbing,dingxing,dingzheng,comment,recipe_no,mobile,update_date) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)';
	
             connection.query(userAddSql,userAddSql_Params,function (err, result) {
	if(err){
		console.log('[INSERT ERROR] - ',err.message);
		return;
	}       
	console.log('-------INSERT----------');
  });
});
