var mysql = require('mysql');  
var TEST_DATABASE = 'frt';  
var TEST_TABLE = 't_recipe';  
//创建连接  
var options = {  
   host     : '127.0.0.1',      
   user     : 'root',             
   password : 'pude2015',      
   port: '3306',                  
   database: TEST_DATABASE ,
};  
var objA = [];
 var vma = new Vue({
    el: '#db_table1',
    data: {
       recipe_results : ''
   }
});

//药方详情
function search_table() {
    var client = mysql.createConnection(options);
    var a= document.getElementById('text').value.trim();
    document.getElementById("prescription").style.display = "none";
    sql="select * from "+TEST_TABLE+" where patient_name like '%"+a+"%' or dingbing like '%"+a+"%' or comment like '%"+a+"%' order by patient_no ,update_date desc";
    if(a !=''){
      client.query(  
         sql , 
          function(err, results, fields) {  
              client.end();
              if (err) {  
                  throw err;  
              }      
       //var objA = [];
       if(results)
       {  
        document.getElementById('count').innerHTML =results.length;
            //   var cols = new Array();
            objH = [];
            for(var i = 0; i < results.length; i++)
            {  
             var newDate = new Date();
             newDate.setTime(results[i].update_date);
             var row = {};
             row.name = results[i].patient_name;
             row.sex = results[i].sex;
             row.age = results[i].age;
             row.doctor = results[i].doctor_name;
             row.dingxing = results[i].dingbing+","+ results[i].dingzheng+","+results[i].dingxing ;
             row.comment  = results[i].comment;
             row.date_time = newDate.toLocaleDateString(results[i].update_date) ;
             row.recipe_no =results[i].recipe_no;
             objH.push(row);
            }
            objA = objH;
            vma.recipe_results = objA;
         }
     });
   }
}
//改变颜色
var CURRENT_ACTIVE = null;
function details(obj,medic){
    console.log(medic);
  obj.style.display = "none";
//  obj.setAttribute('disabled','disabled'); 
    if( null == CURRENT_ACTIVE ){   
        CURRENT_ACTIVE = obj;
    }else if("hidden" ==CURRENT_ACTIVE.parentNode.parentNode.className){
      CURRENT_ACTIVE = obj;
    }
    else { 
        CURRENT_ACTIVE.parentNode.parentNode.className="act";
        CURRENT_ACTIVE = obj;    
    }
    obj.parentNode.parentNode.className="active";   
     obj.parentNode.childNodes[2].style.display = 'block';
 //   obj.parentNode.childNodes[2].removeAttribute('disabled');
    var tr = obj.parentNode.parentNode;
 //   show_detail(tr,medic);
}

//药方表显示

var objC = [];

var vm = new Vue({
         el: '#prescription',
         data: {
             reciper_results : objC
         }
  });  
function show_detail(obj,medic){
    var  patient_name = obj.childNodes[1].innerHTML;
    var date_time = obj.childNodes[13].innerHTML;
    var dingxing = obj.childNodes[9].innerHTML;
   console.log(patient_name);
     console.log(obj);
    var client = mysql.createConnection(options);
    document.getElementById("prescription").style.display = "inline-block";
    client.query(  
        "select medicine,count,unit from t_recipe_item where recipe_id='"+medic + "'", 
        function(err, results, fields) {  
           client.end();
           if (err) { 
                document.write("---------error---------"); 
                throw err;  
                document.write("---------error---------"); 
            }
           if(results)
            { 
                var objB= [];
               for(var i = 0; i < results.length; i++)
               {  
                     var row = {};
                     row.medicine = results[i].medicine;
                     row.count = results[i].count;
                     row.unit= results[i].unit;
                     objB.push(row);
                 } 
                     var objD = {};
                     objD.recipe_no = medic;
                     objD.name=patient_name;
                     objD.date_time=date_time;
                     objD.dingxing = dingxing ;
                     objD.recipe_detail = objB;
                     objC.push(objD);
            //          console.log(objD); 
                 }
       });
}
function removetodo(obj,recip_no){
 console.log(obj);
 obj.parentNode.childNodes[0].style.display = 'block';
 obj.style.display = 'none';
  reciper_array = vm.reciper_results;
  //  console.log(reciper_array.length);
 for(i=0;i<reciper_array.length;i++){
   if(recip_no == reciper_array[i].recipe_no){
      reciper_array.splice(i,1);
      obj.parentNode.parentNode.className="hidden";
    }
  } 
}  