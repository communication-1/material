/*!
 * lib.js v1.0.1
 * (c) 2015 Jin Tian
 * Released under the GPL License.
 */
var _ = require('underscore');
var fs = require('fs');//文件操作的封装
var path = require('path');

var Msg = {
  createNew: function(){
    var msg = {};  //对象
    msg.msg_list = [];//数组
    msg.msg_count = 0;//常量

    //第 msg_count 次写入log
    msg.put = function(a_msg){ 
      //msg.msg_list.push("log " + msg.msg_list.length + ": " + a_msg); 
      msg.msg_count++;
      msg.msg_list.splice(0,0,"\nlog " + msg.msg_count + ": " + a_msg)//插入函数 从第零个开始，替换长度零，替换内容。
      //msg.msg_list.push( a_msg ); 
      
    };

    //下载保存为错误数据记录.txt
    msg.download = function(){
      var evt = document.createEvent("HTMLEvents");  //创建对象
      evt.initEvent("click", false, false);//initEvent 不加后两个参数在FF下会报错

      var blob = new Blob(msg.msg_list);

      var aLink = document.createElement('a');//创建元素<a></a>
      aLink.download = "错误数据记录.txt";
      //URL.createObjectURL()方法会根据传入的参数创建一个指向该参数对象的URL.
      // 这个URL的生命仅存在于它被创建的这个文档里. 新的对象URL指向执行的File对象或者是Blob对象.
      aLink.href = URL.createObjectURL(blob, { "type" : "text/xml" });
      aLink.dispatchEvent(evt);
    }

    return msg;
  }
};

//判断数组 a_array是否存在 temp，返回flag
function check_index(a_array){
  var flag = true;
  for( temp in a_array ){
    //console.log(temp);
    if( a_array[temp] === -1 ){
      flag = false;
    }
  }
  return flag;
}

// 根据关键词，寻找文件名匹配的目标文件。
function find_src_file( base_dir, files_flag ){
  var dest_files = [];// 定义一个数组。

  if(fs.existsSync(base_dir)) {
    console.log('base_dir 存在');

    var all_file = fs.readdirSync(base_dir);//返回一个包含“指定目录下所有文件名称”的数组对象

    for(var i=0; i<files_flag.length; i++){
      var key=files_flag[i];
      var file_name = undefined;

      for(var j=0; j<all_file.length; j++){
        if( all_file[j].indexOf(key) > -1 ){
          var file_name = all_file[j];
        }
      }
      dest_files[key] = file_name;
    }
  } else {
    console.log('base_dir 不存在');
    return null;
  }
  //console.log(dest_files);
  return dest_files;
}

/*
 从二维数组中删除指定的列 
*/
function del_col_from_array(a_array, col_indexs){
  //console.log(a_array);
  var src_col_index = _.range(a_array[0].length);
  var select_index = _.difference(src_col_index, col_indexs);
  return select_col_from_array(a_array, select_index);
}

/*
 从二维数组中取出指定的列 
*/
function select_col_from_array(a_array, col_indexs){
  var dest = [];
  var temp = [];
  for(var i=0; i<a_array.length; i++){
    temp = [];
    for(var j=0; j<col_indexs.length; j++){
      temp.push(a_array[i][col_indexs[j]]);
    }
    dest.push(temp);
  }
  return dest;
}

function trim_array_element( a_array ){
  for( var i=0; i<a_array.length; i++){
    var temp = a_array[i];
    if( temp ){
      if( (typeof temp) == "string" ){
        a_array[i] = temp.trim();
      }else{
        a_array[i] = temp.toString().trim();
      }
    }
  }
}

function isblank(strA){
  if(strA){
    if( "string" === typeof(strA) ){
      if( "" === strA.trim()){
        return true;
      }else{
        return false;
      }
    }else{
      return false;
    }
  }else{
    return true;
  }
}