
var mysql = require('mysql');  
var TEST_DATABASE = 't_recipe';  
var TEST_TABLE = 't_recipe';  
var express = require('express');
var app = express();  
//创建连接  
var client = mysql.createConnection({  
  user: 'root',  
  password: 'pude2015',  
});  
client.connect();
client.query("use " + TEST_DATABASE);
var arr=[];

client.query(  
  'SELECT * FROM '+TEST_TABLE,  
  function(err, results, fields) {  
    if (err) {  
      throw err;  
    }  
      
      if(results)
      {
          for(var i = 0; i < results.length; i++)
          {
		arr[i]=results[i];
           // console.log(results[i].id,results[i].patient_name, results[i].age);
          }
	//for(name in results){console.log(results[name]);}
      }  
        app.get('/', function(req, res) {
        res.send(arr);
    });
 });
   
 
    client.end();
    app.listen(3000);  
