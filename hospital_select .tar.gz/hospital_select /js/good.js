function find_title_index( title_array, t_name){
  var a_index = _.indexOf( title_array, t_name );
  return a_index;
}

function getScore(){

  console.log(vm.xlsx1);
  var arr0=vm.xlsx1[0].data;

  arr3=new Array();
  for(i=0;i<arr0[0].length;i++){
    arr3.push(arr0[0][i]);
  }

  var custorm_id = find_title_index(arr3,'客户名称');
  var count_id = find_title_index(arr3,'实际交货数量');
  var price_id = find_title_index(arr3,'销售价格');
  var material_id = find_title_index(arr3,'物料组描述');
  var city_id = find_title_index(arr3,'城市');
  var adress_id = find_title_index(arr3,'送货地址');
  var logis_id = find_title_index(arr3,'物流通知');
  // alert(typeof custorm_id);

  var arr2=new Array();
  arr2.push(['客户名称','实际交货数量','销售价格','物料组描述','地市','送货地址','物流通知']);
  for(i=1;i<arr0.length;i++){
    //arr2.push=new Array();
    var temp_arr = [];
    temp_arr.push(arr0[i][custorm_id]);
    temp_arr.push(arr0[i][count_id]);
    temp_arr.push(arr0[i][price_id]);
    temp_arr.push(arr0[i][material_id]);
    temp_arr.push(getCity(arr0[i],city_id,i));
    temp_arr.push(arr0[i][adress_id]);
    temp_arr.push(arr0[i][logis_id]);
    arr2.push(temp_arr);
  }
  vm.xlsx1[0].data=arr2;
  console.log(vm.xlsx1[0].data);

  var file=xlsx.build(vm.xlsx1);
  fs.writeFileSync('./data/处理后文件.xlsx',file,'binary');
}


var getCity = function(order, custom_id,row ){

  var ret_city = null;

  var no = "xxx";
  var no2 = "yyy";

  if( typeof(custom_id) === typeof(123) ){
    no = custom_id;
  }else{
    no = parseInt( custom_id );
  }

  var city = order[custom_id].trim();
  // console.log(city);
  if( city.indexOf("西安城区") > -1 ){
    ret_city = "西安城区";
  }else if(city.indexOf("西安郊县")> -1 ){
    ret_city = "西安区县";
  }else if(city.indexOf("西安区县")>-1 ){
    ret_city = "西安区县";
  }else if( city.indexOf("西安市") > -1 ){
    ret_city = "西安城区";
  }else if( city.indexOf("咸阳") > -1 ){
    ret_city = "咸阳";
  }else if( city.indexOf("宝鸡") > -1 ){
    ret_city = "宝鸡";
  }else if( city.indexOf("渭南") > -1 ){
    ret_city = "渭南";
  }else if( city.indexOf("铜川") > -1 ){
    ret_city = "铜川";
  }else if( city.indexOf("延安") > -1 ){
    ret_city = "延安";
  }else if( city.indexOf("榆林") > -1 ){
    ret_city = "榆林";
  }else if( city.indexOf("汉中") > -1 ){
    ret_city = "汉中";
  }else if( city.indexOf("安康") > -1 ){
    ret_city = "安康";
  }else if( city.indexOf("商洛") > -1 ){
    ret_city = "商洛";
  }else{
    ret_city = "西安城区";
    console.log("客户的地区归属出错。 #"+row+"行" + no + "# #" + no2 + "# #" + city + "#");
  }

  return ret_city;
}

function region_cell(){
  var list=xlsx.parse("./data/处理后文件.xlsx");

  var arr0=vm.xlsx1[0].data;
  arr1=new Array();
  for(i=0;i<arr0[0].length;i++){
    arr1.push(arr0[0][i]);
  }
  custom_id = find_title_index(arr1,"地市");
  material_id = find_title_index(arr1,"物料组描述");
  count_id =  find_title_index(arr1,"实际交货数量");
  var city = [];
  city[0] = '行标签';
  var material = [];
  var arr = [];
  //取出 城市 和 物料组描述 列
  for(i=1;i<arr0.length;i++){
    city[i] = arr0[i][custom_id];
    material[i]=arr0[i][material_id];
  }

  //	console.log(material);
  //取唯一
  var city_clear = _.uniq(city);
  var material_clear = _.uniq(material);
  city_clear.push('总计');
  arr.push(city_clear);
  //	console.log(city_clear);
  //	console.log(material_clear);
  var column = new Array();
  column[0] = '总计';
  for(i=1;i<city_clear.length;i++){
    column[i] = 0;}
    for(j=0;j<material_clear.length;j++){
      var material_name = material_clear[j];
      var temp =new Array();

      temp[0] = material_name;

      var num=0;
      for(i=1;i<city_clear.length-1;i++){
        var city_name = city_clear[i];

        var count = 0;
        for(k=1;k<arr0.length;k++){
          if(arr0[k][material_id] == material_name){
            if(typeof(arr0[k][count_id])===typeof(123) && arr0[k][custom_id] === city_name)
              {
                count +=  arr0[k][count_id];
              }

          }
        }
        temp[i] = count;

        num += temp[i];
      }
      temp.push(num);

      for(i=1;i<city_clear.length;i++){
        column[i] += temp[i];}
        arr[j+1]=temp;
    }
    arr.push(column);


    vm.xlsx1[0].data=arr;

    var file=xlsx.build(vm.xlsx1);
    fs.writeFileSync('./data/销售地区业绩.xlsx',file,'binary');
}

